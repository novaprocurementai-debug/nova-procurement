NOVA 2.0 deployment
1. Replace index.html and worker.js in the GitHub repo with these files.
2. Keep the existing wrangler.jsonc unless you already manage D1 through wrangler. The Cloudflare Dashboard D1 binding named DB must remain connected to nova-db, and AI binding must be AI.
3. Keep the Cloudflare secret YEP_API_KEY.
4. Push to main. Cloudflare Git deployment should deploy the Worker.
5. Test /api/network, search, RFQ, landed cost, negotiation, Flash Deals and account login.
Note: 20M+ is a target network size, not a claim of 20M actual records. Search records are created only from real discovered results.
